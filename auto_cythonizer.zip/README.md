# auto_cythonizer

[![PyPI - Version](https://img.shields.io/pypi/v/auto-cythonizer.svg)](https://pypi.org/project/auto-cythonizer)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/auto-cythonizer.svg)](https://pypi.org/project/auto-cythonizer)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install auto-cythonizer
```

## License

`auto-cythonizer` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
